$(document).ready(function() {
    $('#message-close-btn').click(function() {
        $('.django-messages').hide();
    })
})